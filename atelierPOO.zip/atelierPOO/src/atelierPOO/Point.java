package atelierPOO;

class Point {
	private String nom;
	private int abs;
	private int ord;

	
public Point(String nom,int abs,int ord) {
	this.nom = nom;
	this.abs = abs;
	this.ord = ord;
}
public Point(String nom,int abs) {
	
	this.nom=nom;
	this.abs=abs;
}
public Point(int abs,int ord) {
	this.abs=abs;
	this.ord=abs;
}
public Point(String nom) {
	this.nom=nom;
}
public void Affiche() {
	System.out.println(nom+"("+abs+","+ord+")");
}

public void TranslHoriz(int a) {
	{abs=abs+a;}}

public void TranslVert(int a) {
	
	{ord=ord+a;}
}
public void Translation(int a,int b) {
	{abs=abs+a;}
	{ord=ord+a;}
}
public boolean coincide(Point p) {
	return this.abs== p.abs && this.ord==p.ord;
}
public String getnom() {
	return nom;
}
public int getOrdonnees() {
	return ord;
}
public int getabs() {
	return abs;
}
public void setnom(String nom) {
	this.nom=nom;
}
public void setabs(int a) {
	this.abs=a;
}
public void setord(int a) {
	this.ord=a;
}


}