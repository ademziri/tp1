package atelierpoo2;

import java.time.LocalDate;

class MaDate1 {
private int jour;
private int mois;
private int anne;

public MaDate1(int jour,int mois,int anne){
	this.jour=jour;
	this.mois=mois;
	this.anne=anne;
	
}

public MaDate1(int anne){
	this.anne=LocalDate.now().getYear();	
}

public int getjour() {
	return jour;
}
public int getmois() {
	return mois;
}
public int getanne() {
	return anne;
}
public int ajouteran() {
	return anne=anne+1;
}
public int ajoutermois() {
	if(mois==12) {
		return mois=1;
	}
	else {
		return mois=mois+1;
	}
}
public int ajouterunjour() {
	if(jour==30 && (mois==2||mois==4||mois==6||mois==9||mois==11)) {
		return 1;
	}
	else if(jour==31 &&(mois==1||mois==3||mois==5||mois==7||mois==8||mois==10||mois==12)) {
		return 1;
	}
	else {
		return jour=jour+1;
	}
}

public void setjour(int a) {
	this.jour=a;
}
public void setmois(int a) {
	this.mois=a;
}
public void setanne(int a) {
	this.anne=a;
}

public void affdate() {
	System.out.println(jour+"/"+mois+"/"+anne);
}
public void ajouterplsjour(int a) {
	if(jour==30 &&(mois==2||mois==4||mois==6||mois==9||mois==11)){
		jour=0+a;
	}
	else if(jour==30 &&(mois==1||mois==3||mois==5||mois==7||mois==8||mois==10||mois==12)&&a>1){
		jour=-1+a;
	}
	else if(a+jour>30 &&(mois==2||mois==4||mois==6||mois==9||mois==11) ) {
		jour=a-(30-jour);
	}
	else if(a+jour>31 && (mois==1||mois==3||mois==5||mois==7||mois==8||mois==10||mois==12)) {
		jour=a-(31-jour);
	}
		
}




}
