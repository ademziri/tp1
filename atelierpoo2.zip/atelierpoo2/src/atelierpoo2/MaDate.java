package atelierpoo2;

public class MaDate {

	public static void main(String[] args) {
		
MaDate1 d1= new MaDate1(20,5,2004);
MaDate1 d2= new MaDate1(3,7,2008);
MaDate1 d3= new MaDate1(5);
d1.setjour(4);
d2.setmois(5);
d3.setanne(2003);
d1.affdate();
d2.affdate();
d3.affdate();


	}

}
